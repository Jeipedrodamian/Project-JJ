#!/usr/bin/env python3
"""
Hello World Program in Python
A comprehensive demonstration of various ways to output "Hello, World!"
"""

# Basic Hello World
print("=== BASIC HELLO WORLD ===")
print("Hello, World!")

# Using variables
print("\n=== USING VARIABLES ===")
message = "Hello, World!"
print(message)

# Using a function
print("\n=== USING FUNCTIONS ===")
def hello_world():
    """Function that returns Hello World"""
    return "Hello, World!"

def greet(name="World"):
    """Function that greets a specific name"""
    return f"Hello, {name}!"

print(hello_world())
print(greet())
print(greet("Python"))

# Using a class
print("\n=== USING CLASSES ===")
class Greeter:
    """A class that handles greetings"""
    
    def __init__(self, greeting="Hello"):
        self.greeting = greeting
    
    def greet(self, name="World"):
        """Method to greet someone"""
        return f"{self.greeting}, {name}!"
    
    def greet_multiple(self, names):
        """Method to greet multiple people"""
        greetings = []
        for name in names:
            greetings.append(f"{self.greeting}, {name}!")
        return greetings

# Create greeter instances
english_greeter = Greeter()
spanish_greeter = Greeter("Hola")
french_greeter = Greeter("Bonjour")

print(english_greeter.greet())
print(spanish_greeter.greet("Mundo"))
print(french_greeter.greet("Monde"))

# Greet multiple people
names = ["Alice", "Bob", "Charlie"]
greetings = english_greeter.greet_multiple(names)
print("Multiple greetings:", greetings)

# Different string formatting methods
print("\n=== STRING FORMATTING METHODS ===")
name = "World"

# f-strings (Python 3.6+)
print(f"Hello, {name}!")

# .format() method
print("Hello, {}!".format(name))
print("Hello, {name}!".format(name=name))

# % formatting (older style)
print("Hello, %s!" % name)

# String concatenation
print("Hello, " + name + "!")

# Interactive version
print("\n=== INTERACTIVE VERSION ===")
def interactive_hello():
    """Interactive hello world with user input"""
    name = input("What's your name? (Press Enter for 'World'): ").strip()
    if not name:
        name = "World"
    
    language = input("Choose language (1-English, 2-Spanish, 3-French): ").strip()
    
    greetings = {
        '1': "Hello",
        '2': "Hola", 
        '3': "Bonjour"
    }
    
    greeting = greetings.get(language, "Hello")
    print(f"{greeting}, {name}!")

# Uncomment the line below to run interactive version
# interactive_hello()

# File output version
print("\n=== FILE OUTPUT VERSION ===")
def hello_to_file():
    """Write hello world to a file"""
    with open('hello_world.txt', 'w') as file:
        file.write("Hello, World!\n")
        file.write("This was written by Python!\n")
    print("Hello message written to 'hello_world.txt'")

hello_to_file()

# Reading back from file
print("\n=== READING FROM FILE ===")
try:
    with open('hello_world.txt', 'r') as file:
        content = file.read()
        print("Content from file:")
        print(content)
except FileNotFoundError:
    print("File not found!")

# Advanced: Hello World with timing
print("\n=== TIMED VERSION ===")
import time

def timed_hello():
    """Hello world with execution timing"""
    start_time = time.time()
    
    # Simulate some processing
    messages = []
    for i in range(5):
        messages.append(f"Hello, World! Message #{i+1}")
        time.sleep(0.1)  # Small delay
    
    for msg in messages:
        print(msg)
    
    end_time = time.time()
    execution_time = end_time - start_time
    print(f"Execution time: {execution_time:.2f} seconds")

timed_hello()

# Hello World with error handling
print("\n=== VERSION WITH ERROR HANDLING ===")
def safe_hello():
    """Hello world with proper error handling"""
    try:
        # Simulate a potential error
        user_input = input("Enter a number to divide by (or press Enter for default): ").strip()
        if user_input:
            number = int(user_input)
            result = 100 / number
            print(f"100 / {number} = {result}")
        
        print("Hello, World! (No errors occurred)")
        
    except ValueError:
        print("Error: Please enter a valid number!")
    except ZeroDivisionError:
        print("Error: Cannot divide by zero!")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
    finally:
        print("Hello World program completed!")

# Uncomment to run error-handling version
# safe_hello()

# Command Line Arguments version
print("\n=== COMMAND LINE ARGUMENTS VERSION ===")
import sys

def hello_from_args():
    """Hello world using command line arguments"""
    if len(sys.argv) > 1:
        name = ' '.join(sys.argv[1:])
        print(f"Hello, {name}!")
    else:
        print("Hello, World!")
        print("Usage: python hello_world.py [name]")

# This will run when the script is executed directly
if __name__ == "__main__":
    print("=" * 50)
    print("MAIN PROGRAM EXECUTION")
    print("=" * 50)
    
    # Run the basic version
    print(hello_world())
    
    # Run command line version
    hello_from_args()
    
    print("\n" + "=" * 50)
    print("All Hello World examples completed successfully!")
    print("=" * 50)